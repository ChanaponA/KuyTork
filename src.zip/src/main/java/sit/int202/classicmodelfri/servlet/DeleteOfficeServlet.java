package sit.int202.classicmodelfri.servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import sit.int202.classicmodelfri.entities.Office;
import sit.int202.classicmodelfri.repositories.OfficeRepository;

import java.io.IOException;

@WebServlet("/deleteOffice")
public class DeleteOfficeServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve office code from request parameters
        String officeCode = request.getParameter("officeCode");

        // Check if the office has associated employees
        OfficeRepository officeRepository = new OfficeRepository();
        Office officeToDelete = officeRepository.find(officeCode);

        if (officeToDelete != null && officeToDelete.getEmployeeList() != null && !officeToDelete.getEmployeeList().isEmpty()) {
            // Office has associated employees, cannot delete
            // Display an alert message to the user
            response.getWriter().println("Cannot delete office with code " + officeCode + ". It has associated employees.");

            // Redirect back to the office list without performing deletion
            response.sendRedirect(request.getContextPath() + "/office_list");
        } else {
            // Delete the office using the OfficeRepository
            boolean success = officeRepository.delete(officeCode);

            if (success) {
                // Redirect to the office list after successful deletion
                response.sendRedirect(request.getContextPath() + "/office_list");
            } else {
                // Handle deletion failure (e.g., display an error message)
                // You can customize this part based on your application's needs
                response.getWriter().println("Failed to delete office with code: " + officeCode);
            }
        }
    }
}
