package sit.int202.classicmodelfri.servlet;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import sit.int202.classicmodelfri.entities.Office;
import sit.int202.classicmodelfri.repositories.OfficeRepository;

import java.io.IOException;

@WebServlet(name = "UpdateOfficeServlet", value = "/UpdateOffice")
public class UpdateOfficeServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve office details from the request parameters
        String officeCode = request.getParameter("officeCode");
        String addressLine1 = request.getParameter("addressLine1");
        String addressLine2 = request.getParameter("addressLine2");
        String city = request.getParameter("city");
        String state = request.getParameter("state");
        String country = request.getParameter("country");
        String postalCode = request.getParameter("postalCode");
        String phone = request.getParameter("phone");
        String territory = request.getParameter("territory");

        // Create an Office object with the retrieved details
        Office updatedOffice = new Office();
        updatedOffice.setOfficeCode(officeCode);
        updatedOffice.setAddressLine1(addressLine1);
        updatedOffice.setAddressLine2(addressLine2);
        updatedOffice.setCity(city);
        updatedOffice.setState(state);
        updatedOffice.setCountry(country);
        updatedOffice.setPostalCode(postalCode);
        updatedOffice.setPhone(phone);
        updatedOffice.setTerritory(territory);

        // Update the office using the OfficeRepository
        OfficeRepository officeRepository = new OfficeRepository();
        boolean success = officeRepository.update(updatedOffice);

        if (success) {
            // Redirect to the office list
            response.sendRedirect(request.getContextPath() + "/office_list?officeCode=" + officeCode);
        } else {
            // Handle the case where the update fails (e.g., show an error message)
            response.sendRedirect(request.getContextPath() + "/error.jsp");
        }
    }
}