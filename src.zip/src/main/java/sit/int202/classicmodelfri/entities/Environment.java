package sit.int202.classicmodelfri.entities;

public class Environment {
    public static final String PU_NAME = "classic-models";
}
