package sit.int202.classicmodelfri.servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import sit.int202.classicmodelfri.entities.Office;
import sit.int202.classicmodelfri.repositories.OfficeRepository;

import java.io.IOException;

@WebServlet("/insertOffice")
public class InsertOfficeServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve office details from the request parameters
        String officeCode = request.getParameter("officeCode");
        String addressLine1 = request.getParameter("addressLine1");
        String addressLine2 = request.getParameter("addressLine2");
        String city = request.getParameter("city");
        String state = request.getParameter("state");
        String country = request.getParameter("country");
        String postalCode = request.getParameter("postalCode");
        String phone = request.getParameter("phone");
        String territory = request.getParameter("territory");

        // Create an Office object with the retrieved details
        Office newOffice = new Office();
        newOffice.setOfficeCode(officeCode);
        newOffice.setAddressLine1(addressLine1);
        newOffice.setAddressLine2(addressLine2);
        newOffice.setCity(city);
        newOffice.setState(state);
        newOffice.setCountry(country);
        newOffice.setPostalCode(postalCode);
        newOffice.setPhone(phone);
        newOffice.setTerritory(territory);

        // Insert the new office using the OfficeRepository
        OfficeRepository officeRepository = new OfficeRepository();
        boolean success = officeRepository.insert(newOffice);


// Redirect to a confirmation page or back to the office list
        response.sendRedirect(request.getContextPath() + "/office_list.jsp");
    }
}
